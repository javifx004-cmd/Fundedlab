# Calendario de Instagram · 91 días · @fundedlab_es

Del 2026-10-19 al 2027-01-17. Una publicación al día: cada carpeta tiene la imagen, las imágenes del
carrusel (súbelas en orden) o el reel, y `texto.txt` con el pie de foto y los hashtags.

- **Reels:** sin música. Al subirlos, toca «Audio» en Instagram y elige una canción en tendencia.
- **Mejor hora:** 13:00–14:00 o 20:00–21:30 hora de España. Los reels de las sesiones, mejor por la tarde.
- **Fechas especiales** (cambios de hora, Fed, Acción de Gracias, vencimiento de diciembre, Navidad): revisa siempre el
  calendario económico por si cambia algo.
- **Precios de los gráficos:** ilustrativos; ya lo indica cada publicación.

| Nº | Fecha | Día | Tipo | Tema | Primera línea del texto |
|---|---|---|---|---|---|
| 1 | 2026-10-19 | lunes | carrusel | la ventana 1515 | La ventana de 15:15 a 15:30: por qué esos 15 minutos y no otros 🕒 |
| 2 | 2026-10-20 | martes | reel | reel sesion ganadora | Así opero la apertura de Nueva York en 30 segundos ⏱️ |
| 3 | 2026-10-21 | miércoles | post | regla | 📌 Una operación al día. |
| 4 | 2026-10-22 | jueves | reel | reel operarias este dia | ¿Operarías este día? 🤔 Comenta SÍ o NO antes de ver el final 👇 |
| 5 | 2026-10-23 | viernes | carrusel | tu rutina diaria | Mi rutina de cada día, de 14:45 a la hora límite ⏰ |
| 6 | 2026-10-24 | sábado | post | cambio de hora europa | ⚠️ Mañana cambia la hora en Europa, pero NO en EE. UU. |
| 7 | 2026-10-25 | domingo | post | curso ya disponible | Mi curso de trading de futuros ya está disponible 🚀 |
| 8 | 2026-10-26 | lunes | carrusel | anatomia de una vela | Si no sabes leer una vela, no sabes leer el mercado 🕯️ |
| 9 | 2026-10-27 | martes | reel | reel sesion ganadora | Ruptura de las 15:15 paso a paso ⏱️ |
| 10 | 2026-10-28 | miércoles | post | hoy hay fed | 🏦 Hoy hay decisión de la Fed. |
| 11 | 2026-10-29 | jueves | reel | reel operarias este dia | ¿Operarías este día? 🤔 Comenta SÍ o NO antes de ver el final 👇 |
| 12 | 2026-10-30 | viernes | carrusel | errores 1 a 5 | 5 errores que queman cuentas de fondeo (y la regla que evita cada uno) 🔥 |
| 13 | 2026-10-31 | sábado | post | cambio de hora eeuu | ⏰ Mañana cambia la hora en EE. UU. |
| 14 | 2026-11-01 | domingo | post | curso qué incluye | Todo lo que incluye el curso 👇 |
| 15 | 2026-11-02 | lunes | carrusel | tu rango es una vela | Truco: tu rango de 15:15 a 15:30 es UNA sola vela 🤯 |
| 16 | 2026-11-03 | martes | reel | reel sesion perdedora | El día que pierdes: también tiene reglas ❌ |
| 17 | 2026-11-04 | miércoles | post | regla | 📌 El stop solo se mueve a favor. |
| 18 | 2026-11-05 | jueves | reel | reel operarias este dia | ¿Operarías este día? 🤔 Comenta SÍ o NO antes de ver el final 👇 |
| 19 | 2026-11-06 | viernes | carrusel | errores 6 a 10 | Otros 5 errores que cuestan dinero (el 7 es MUY típico estas semanas) 👇 |
| 20 | 2026-11-07 | sábado | post | glosario | 📖 Glosario del trader: Acumulación |
| 21 | 2026-11-08 | domingo | post | curso ejemplos interactivos | Así son los ejemplos del curso: ves el gráfico a las 15:30, eliges qué harías y después ves la resolución vela a vela 🧠 |
| 22 | 2026-11-09 | lunes | carrusel | seis patrones de velas | 6 patrones de velas que tienes que reconocer 👀 |
| 23 | 2026-11-10 | martes | reel | reel sesion ganadora | Un día con el método sin tocar nada ⏱️ |
| 24 | 2026-11-11 | miércoles | post | regla | 📌 Si no entraste en tu nivel, no es tu operación. |
| 25 | 2026-11-12 | jueves | reel | reel operarias este dia | ¿Operarías este día? 🤔 Comenta SÍ o NO antes de ver el final 👇 |
| 26 | 2026-11-13 | viernes | carrusel | fondeo que vigilar | Cuentas de fondeo: lo que tienes que vigilar con esta estrategia 🏦 |
| 27 | 2026-11-14 | sábado | post | glosario | 📖 Glosario del trader: Ruptura falsa |
| 28 | 2026-11-15 | domingo | post | curso calculadora | Pones tu riesgo y el contrato, y te dice cuántos operar. Se acabó operar a ojo 🧮 |
| 29 | 2026-11-16 | lunes | carrusel | nq o mnq | NQ o MNQ: cuánto vale cada punto y por qué importa más que la garantía 💵 |
| 30 | 2026-11-17 | martes | reel | reel sesion ganadora | 15 minutos de rango y una sola operación ⏱️ |
| 31 | 2026-11-18 | miércoles | post | regla | 📌 El tamaño se decide por la pérdida, no por la garantía. |
| 32 | 2026-11-19 | jueves | reel | reel operarias este dia | ¿Operarías este día? 🤔 Comenta SÍ o NO antes de ver el final 👇 |
| 33 | 2026-11-20 | viernes | carrusel | tamano segun la cuenta | Cuántos contratos operar según el tamaño de tu cuenta de fondeo 📐 |
| 34 | 2026-11-21 | sábado | post | glosario | 📖 Glosario del trader: OCO |
| 35 | 2026-11-22 | domingo | post | curso para quién es | ¿Es para ti? 👇 |
| 36 | 2026-11-23 | lunes | carrusel | tipos de ordenes | Stop, límite, OCO, bracket… ¿cuál usar en cada momento? 🎯 |
| 37 | 2026-11-24 | martes | reel | reel sesion perdedora | Un día perdedor: bien gestionado ❌ |
| 38 | 2026-11-25 | miércoles | post | regla | 📌 Un día perdedor dentro del plan es una buena operación. |
| 39 | 2026-11-26 | jueves | post | accion de gracias | 🦃 Hoy es Acción de Gracias en EE. UU.: la bolsa de Nueva York está cerrada. Sin apertura no hay ventana ni operación. |
| 40 | 2026-11-27 | viernes | carrusel | caso drawdown trailing | Ganas la operación… y pierdes margen en la cuenta de fondeo. ¿Cómo? 🤔 |
| 41 | 2026-11-28 | sábado | post | glosario | 📖 Glosario del trader: Bracket |
| 42 | 2026-11-29 | domingo | post | curso vídeos | Un vídeo por cada módulo, con las operaciones repetidas vela a vela 🎬 |
| 43 | 2026-11-30 | lunes | carrusel | oco y bracket | La combinación de órdenes que uso cada día a las 15:30 ⚙️ |
| 44 | 2026-12-01 | martes | reel | reel sesion ganadora | La apertura de Nueva York vela a vela ⏱️ |
| 45 | 2026-12-02 | miércoles | post | regla | 📌 Sin compresión hasta las 15:30, no hay operación. |
| 46 | 2026-12-03 | jueves | reel | reel operarias este dia | ¿Operarías este día? 🤔 Comenta SÍ o NO antes de ver el final 👇 |
| 47 | 2026-12-04 | viernes | carrusel | trampas mentales | La mayoría de cuentas no se pierden por la estrategia, sino por romperla 🧠 |
| 48 | 2026-12-05 | sábado | post | glosario | 📖 Glosario del trader: Drawdown |
| 49 | 2026-12-06 | domingo | post | curso acceso | Pregunta frecuente: ¿cuánto dura el acceso? ⏳ |
| 50 | 2026-12-07 | lunes | carrusel | rango y ruptura | El mercado alterna entre rangos y tendencias. Esta estrategia vive en el paso de uno a otro 📈 |
| 51 | 2026-12-08 | martes | reel | reel sesion ganadora | Stop y objetivo desde el primer segundo y a esperar ⏱️ |
| 52 | 2026-12-09 | miércoles | post | hoy hay fed diciembre | 🏦 Hoy hay decisión de la Fed: comunicado a las 20:00 hora española. |
| 53 | 2026-12-10 | jueves | reel | reel operarias este dia | ¿Operarías este día? 🤔 Comenta SÍ o NO antes de ver el final 👇 |
| 54 | 2026-12-11 | viernes | carrusel | cambio de contrato diciembre | Cambio de contrato: el NQ de diciembre (NQZ6) vence el viernes 18. ¿Ya operas el de marzo? 📆 |
| 55 | 2026-12-12 | sábado | post | glosario | 📖 Glosario del trader: Tick |
| 56 | 2026-12-13 | domingo | post | curso experiencia | Pregunta frecuente: ¿necesito experiencia previa? 🤔 |
| 57 | 2026-12-14 | lunes | carrusel | rango valido o no | ¿Cuándo un rango es válido y cuándo ese día NO se opera? ✅❌ |
| 58 | 2026-12-15 | martes | reel | reel sesion perdedora | Ruptura falsa: y qué hacer después ❌ |
| 59 | 2026-12-16 | miércoles | post | regla | 📌 Planifica la operación y opera el plan. |
| 60 | 2026-12-17 | jueves | reel | reel operarias este dia | ¿Operarías este día? 🤔 Comenta SÍ o NO antes de ver el final 👇 |
| 61 | 2026-12-18 | viernes | carrusel | caso doble ruptura | Rompe arriba, te saca… y luego cae 200 puntos. ¿Vuelves a entrar? 😬 |
| 62 | 2026-12-19 | sábado | post | glosario | 📖 Glosario del trader: Deslizamiento |
| 63 | 2026-12-20 | domingo | post | curso navidad | Regálate (o regala) un método para 2027 🎁 |
| 64 | 2026-12-21 | lunes | carrusel | stop o cierre de vela | Mismo día, dos métodos de entrada, dos resultados distintos 🤯 |
| 65 | 2026-12-22 | martes | reel | reel sesion ganadora | El método en una sesión de principio a fin ⏱️ |
| 66 | 2026-12-23 | miércoles | post | regla | 📌 100 sesiones de backtest antes de dinero real. |
| 67 | 2026-12-24 | jueves | post | nochebuena | 🎄 Hoy la sesión de EE. UU. es más corta y con muy poco volumen. Las rupturas sin volumen son menos fiables. |
| 68 | 2026-12-25 | viernes | post | navidad | 🎄 Feliz Navidad. Hoy los mercados están cerrados. |
| 69 | 2026-12-26 | sábado | post | glosario | 📖 Glosario del trader: Trailing stop |
| 70 | 2026-12-27 | domingo | post | curso fondeo | Pregunta frecuente: ¿sirve para cuentas de fondeo? 🏦 |
| 71 | 2026-12-28 | lunes | carrusel | rr 1 1 y acierto | Con un riesgo/beneficio 1:1, ¿qué porcentaje de acierto necesitas? 🧮 |
| 72 | 2026-12-29 | martes | reel | reel sesion ganadora | Así se ve una ruptura limpia en el Nasdaq ⏱️ |
| 73 | 2026-12-30 | miércoles | post | regla | 📌 El peor caso de la posición, siempre positivo. |
| 74 | 2026-12-31 | jueves | post | nochevieja | 🥂 Último día de 2026. |
| 75 | 2027-01-01 | viernes | carrusel | tu plan de trading 2027 | Año nuevo, plan nuevo: las 12 preguntas que tiene que responder tu plan de trading 📝 |
| 76 | 2027-01-02 | sábado | post | glosario | 📖 Glosario del trader: Piramidar |
| 77 | 2027-01-03 | domingo | post | curso año nuevo | Empieza 2027 con un plan, no con corazonadas 📝 |
| 78 | 2027-01-04 | lunes | carrusel | promediar a favor | Promediar a favor sin arriesgar el día: el peor caso siempre positivo 🧠 |
| 79 | 2027-01-05 | martes | reel | reel sesion perdedora | −80 y a casa: así se protege una cuenta ❌ |
| 80 | 2027-01-06 | miércoles | post | regla | 📌 Tu peor enemigo no es el mercado. Es saltarte tus reglas. |
| 81 | 2027-01-07 | jueves | reel | reel operarias este dia | ¿Operarías este día? 🤔 Comenta SÍ o NO antes de ver el final 👇 |
| 82 | 2027-01-08 | viernes | carrusel | casos deslizamiento y 70 | Dos situaciones que pasan más de lo que crees: deslizamiento y «llegó a +70 y se giró» 🙃 |
| 83 | 2027-01-09 | sábado | post | glosario | 📖 Glosario del trader: RR (riesgo/beneficio) |
| 84 | 2027-01-10 | domingo | post | curso método | El método completo cabe en 5 reglas. Lo difícil es cumplirlas 👇 |
| 85 | 2027-01-11 | lunes | carrusel | como hacer un backtest | Ninguna regla está demostrada hasta que la pruebas con 100 sesiones 📊 |
| 86 | 2027-01-12 | martes | reel | reel sesion ganadora | Rompe, entras y dejas trabajar el plan ⏱️ |
| 87 | 2027-01-13 | miércoles | post | regla | 📌 Revisa el calendario macro antes de las 15:15. |
| 88 | 2027-01-14 | jueves | reel | reel operarias este dia | ¿Operarías este día? 🤔 Comenta SÍ o NO antes de ver el final 👇 |
| 89 | 2027-01-15 | viernes | carrusel | checklist diaria | La checklist que repaso cada día antes de las 15:15 ✅ |
| 90 | 2027-01-16 | sábado | post | glosario | 📖 Glosario del trader: Break-even |
| 91 | 2027-01-17 | domingo | post | curso compartir | Cada alumno tiene su acceso personal, con su correo en todo el contenido 🔐 |
